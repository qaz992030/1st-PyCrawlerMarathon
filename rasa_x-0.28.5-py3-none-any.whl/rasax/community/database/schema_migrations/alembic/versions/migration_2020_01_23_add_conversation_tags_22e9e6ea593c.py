"""This migration is left empty because of issue with 0.25.0 release.

After merging 0.24.x to the master this migration was originally never applied.
Check migrations: 0b35090e53cf

Revision ID: 22e9e6ea593c
Revises: 443af39e50e3

"""

# revision identifiers, used by Alembic.
revision = "22e9e6ea593c"
down_revision = "443af39e50e3"
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
